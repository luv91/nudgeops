"""
NudgeOps - Runtime semantic guardrails for AI agents.

Detect loops. Nudge agents back on track. Stop runaway costs.
"""

from nudgeops.core.state import (
    AgentState,
    DetectionResult,
    GuardConfig,
    LoopStatus,
    StepRecord,
)
from nudgeops.core.detectors import (
    BaseDetector,
    InsanityDetector,
    PhantomProgressDetector,
    PingPongDetector,
    StutterDetector,
)
from nudgeops.core.scorer import LoopScorer
from nudgeops.core.interventions import InterventionManager
from nudgeops.integrations.apply_guard import apply_guard
from nudgeops.integrations.universal_guard import UniversalGuard, GuardDecision
from nudgeops.integrations.langgraph import (
    NudgeOpsNode,
    NudgeOpsState,
    add_guard_to_graph,
)

__version__ = "0.1.0"

__all__ = [
    # State types
    "AgentState",
    "StepRecord",
    "DetectionResult",
    "LoopStatus",
    "GuardConfig",
    # Detectors
    "BaseDetector",
    "StutterDetector",
    "InsanityDetector",
    "PhantomProgressDetector",
    "PingPongDetector",
    # Scoring
    "LoopScorer",
    # Interventions
    "InterventionManager",
    # Integration
    "NudgeOpsNode",
    "NudgeOpsState",
    "add_guard_to_graph",
    "apply_guard",
    "UniversalGuard",
    "GuardDecision",
]
